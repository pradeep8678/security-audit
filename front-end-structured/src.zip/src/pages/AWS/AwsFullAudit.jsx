import { useState } from "react";
import client from "../../api/client";
import ExportToExcel from "../../components/Exports/ExportToExcel";
import ExportToPDF from "../../components/Exports/ExportToPDF";
import styles from "../../styles/FullAudit.module.css";

export default function AwsFullAudit({ credentials }) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState({});
  const [error, setError] = useState("");
  const [selectedResource, setSelectedResource] = useState(null);
  const [showDropdown, setShowDropdown] = useState(false);

  // AWS resources list (like GCP resourceList)
  const resourceList = [
    "EC2 Instances",
    "S3 Buckets",
    "Load Balancers",
    "IAM Users & Roles",
    "Security Groups",
    "EKS Clusters",
    "App Runner Services",
    "RDS Databases",
  ];

  const readable = (value) => {
    if (Array.isArray(value)) return value.map((v) => readable(v)).join(", ");
    if (typeof value === "object" && value !== null)
      return Object.entries(value)
        .map(([k, v]) => `${k}: ${readable(v)}`)
        .join(", ");
    return value;
  };

  const handleFullAudit = async () => {
    if (!credentials?.accessKeyId || !credentials?.secretAccessKey) {
      alert("Please enter AWS Access Key ID and Secret Key first.");
      return;
    }

    setLoading(true);
    setError("");
    setResult({});

    try {
      // If client baseURL = http://localhost:8080/api
      const res = await client.post("/aws-full-audit", {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      });

      const normalizedResult = {};

      (res.data.results || []).forEach((item) => {
        // For failed checks, keep error so we can show it
        if (item.success && item.result) {
          normalizedResult[item.name] = item.result;
        } else {
          normalizedResult[item.name] = { error: item.error || "Unknown error" };
        }
      });

      setResult(normalizedResult);
    } catch (err) {
      console.error("AWS full audit error:", err);
      setError(
        err.response?.data?.detail ||
          err.response?.data?.message ||
          "AWS full audit failed"
      );
    } finally {
      setLoading(false);
    }
  };

  // You can add AWS-specific recommendations later here
  const addRecommendation = (items, name) => {
    return items.map((item) => {
      if (item.recommendation) return item;

      let rec = "";

      if (name === "EC2 Instances") {
        const ip = item.publicIp || item.publicIP || "unknown";
        rec = `This EC2 instance is publicly accessible with IP ${ip}. Place it in private subnet and use bastion / VPN.`;
      } else if (name === "S3 Buckets") {
        rec =
          "Review S3 bucket public access settings. Ensure Block Public Access is enabled and IAM policies follow least privilege.";
      } else if (name === "Security Groups") {
        rec =
          "Security Group has open ports. Restrict 0.0.0.0/0 and limit access to required CIDR ranges only.";
      } else if (name === "Load Balancers") {
        rec =
          "Verify listeners, SSL policies, and attached security groups. Ensure only intended services are publicly reachable.";
      } else if (name === "IAM Users & Roles") {
        rec =
          "Review IAM users/roles for admin privileges and enable MFA. Apply least privilege and clean up unused access keys.";
      } else if (name === "EKS Clusters") {
        rec =
          "Ensure EKS API endpoint access is restricted, enable private endpoint if possible, and tighten node role permissions.";
      } else if (name === "RDS Databases") {
        rec =
          "Ensure RDS is not publicly accessible, storage is encrypted, and automated backups/monitoring are enabled.";
      } else if (name === "App Runner Services") {
        rec =
          "Verify App Runner services networking and IAM roles. Limit public exposure and secure environment variables.";
      }

      return { ...item, recommendation: rec };
    });
  };

  const renderTable = (items, name) => {
    if (!items || items.length === 0)
      return <p className={styles.noData}>No data available</p>;

    const enriched = addRecommendation(items, name);
    const headers = [...new Set([...Object.keys(enriched[0])])];

    return (
      <table className={styles.table}>
        <thead>
          <tr>
            {headers.map((key) => (
              <th key={key}>{key}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {enriched.map((item, idx) => (
            <tr key={idx}>
              {headers.map((key) => (
                <td key={key}>{readable(item[key] ?? "-")}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  const renderResource = (name) => {
    if (!result[name]) return null;

    // Map AWS resource name → field that holds the array
    const mapping = {
      "EC2 Instances": "instances",
      "S3 Buckets": "buckets",
      "Load Balancers": "loadBalancers",
      "IAM Users & Roles": "items",       // adjust when your backend is ready
      "Security Groups": "groups",        // adjust field names later
      "EKS Clusters": "clusters",
      "App Runner Services": "services",
      "RDS Databases": "databases",
    };

    const field = mapping[name] || null;
    const resourceResult = result[name];

    // If backend returned error for this resource
    if (resourceResult.error) {
      return (
        <div className={styles.card}>
          <h3 className={styles.cardTitle}>{name}</h3>
          <p className={styles.error}>❌ {resourceResult.error}</p>
        </div>
      );
    }

    if (!field || !resourceResult[field]) {
      return (
        <div className={styles.card}>
          <h3 className={styles.cardTitle}>{name}</h3>
          <p className={styles.noData}>No structured list found for this resource yet.</p>
        </div>
      );
    }

    return (
      <div className={styles.card}>
        <h3 className={styles.cardTitle}>{name}</h3>
        {renderTable(resourceResult[field], name)}
      </div>
    );
  };

  return (
    <div className={styles.container}>
      <div className={styles.subbox}>
        <div className={styles.center}>
          <button
            onClick={handleFullAudit}
            disabled={loading}
            className={loading ? styles.btnDisabled : styles.btnPrimary}
          >
            {loading ? "Running..." : "Run Full AWS Audit"}
          </button>

          {Object.keys(result).length > 0 && (
            <div className={styles.dropdownWrapper}>
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className={styles.btnSuccess}
              >
                Download ▼
              </button>

              {showDropdown && (
                <div className={styles.dropdownMenu}>
                  <div>
                    <ExportToExcel
                      auditResult={result}
                      onClick={() => setShowDropdown(false)}
                    />
                  </div>
                  <div>
                    <ExportToPDF
                      auditResult={result}
                      onClick={() => setShowDropdown(false)}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {error && <p className={styles.error}>{error}</p>}

        <div className={styles.selectorWrapper}>
          <div
            onClick={() => setSelectedResource(null)}
            className={selectedResource === null ? styles.selectedChip : styles.chip}
          >
            All
          </div>

          {resourceList.map((res) => (
            <div
              key={res}
              onClick={() => setSelectedResource(res)}
              className={
                selectedResource === res ? styles.selectedChip : styles.chip
              }
            >
              {res}
            </div>
          ))}
        </div>
      </div>

      {selectedResource
        ? renderResource(selectedResource)
        : resourceList.map((res) => renderResource(res))}
    </div>
  );
}
