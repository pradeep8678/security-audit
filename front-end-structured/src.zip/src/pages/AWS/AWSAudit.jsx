import { useState } from "react";
import AwsFullAudit from "./AwsFullAudit";
import styles from "../../styles/FullAudit.module.css";

export default function AWSAudit() {
  const [accessKeyId, setAccessKeyId] = useState("");
  const [secretAccessKey, setSecretAccessKey] = useState("");

  const credentials = { accessKeyId, secretAccessKey };

  return (
    <div className={styles.container}>
      {/* You can style these better later or re-use dropzone style */}
      <div className={styles.dropzone}>
        <h2 className={styles.dropzoneTitle}>AWS Credentials</h2>
        <p className={styles.dropzoneSub}>
          Enter your AWS Access Key ID and Secret Key to run a full audit.
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          <input
            type="text"
            placeholder="AWS Access Key ID"
            value={accessKeyId}
            onChange={(e) => setAccessKeyId(e.target.value)}
            style={{
              padding: "12px",
              borderRadius: "8px",
              border: "1px solid #ccd4ff",
              fontSize: "14px",
            }}
          />

          <input
            type="password"
            placeholder="AWS Secret Access Key"
            value={secretAccessKey}
            onChange={(e) => setSecretAccessKey(e.target.value)}
            style={{
              padding: "12px",
              borderRadius: "8px",
              border: "1px solid #ccd4ff",
              fontSize: "14px",
            }}
          />
        </div>
      </div>

      <AwsFullAudit credentials={credentials} />
    </div>
  );
}
