const {
  EC2Client,
  DescribeInstancesCommand,
  DescribeRegionsCommand
} = require("@aws-sdk/client-ec2");

exports.listEC2Instances = async (req, res) => {
  try {
    const { accessKeyId, secretAccessKey } = req.body;

    if (!accessKeyId || !secretAccessKey) {
      return res.status(400).json({
        error: "Missing AWS credentials (accessKeyId, secretAccessKey)"
      });
    }

    // Base client (used to fetch all regions)
    const baseClient = new EC2Client({
      region: "us-east-1",
      credentials: { accessKeyId, secretAccessKey }
    });

    // Step 1 — Get all AWS regions
    const regionData = await baseClient.send(new DescribeRegionsCommand({}));
    const allRegions = regionData.Regions.map(r => r.RegionName);

    console.log("🌎 Scanning regions:", allRegions.join(", "));

    let vulnerableInstances = [];

    // Step 2 — Scan each region for EC2 instances
    for (const region of allRegions) {
      const client = new EC2Client({
        region,
        credentials: { accessKeyId, secretAccessKey }
      });

      console.log(`🔍 Checking region: ${region}`);

      try {
        const response = await client.send(new DescribeInstancesCommand({}));

        const reservations = response.Reservations || [];

        reservations.forEach((r) => {
          (r.Instances || []).forEach((instance) => {
            const publicIP = instance.PublicIpAddress;

            if (publicIP) {
              vulnerableInstances.push({
                instanceId: instance.InstanceId,
                region,
                instanceType: instance.InstanceType,
                publicIP,
                privateIP: instance.PrivateIpAddress || null,
                state: instance.State?.Name,
                launchTime: instance.LaunchTime
              });
            }
          });
        });
      } catch (err) {
        console.warn(`⚠️ Skipping region ${region}: ${err.message}`);
      }
    }

    console.log(`✅ Found ${vulnerableInstances.length} public EC2 instances.`);

    return res.json({
      message: "AWS EC2 Public VM audit completed successfully",
      scannedRegions: allRegions.length,
      totalPublicInstances: vulnerableInstances.length,
      instances: vulnerableInstances
    });

  } catch (error) {
    console.error("❌ AWS EC2 Audit Error:", error);
    return res.status(500).json({ error: error.message });
  }
};
